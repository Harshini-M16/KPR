// DOM Elements
const generateBtn = document.getElementById('generateBtn');
const copyBtn = document.getElementById('copyBtn');
const passwordDisplay = document.getElementById('password');
const lengthInput = document.getElementById('length');
const uppercaseCheckbox = document.getElementById('uppercase');
const lowercaseCheckbox = document.getElementById('lowercase');
const numbersCheckbox = document.getElementById('numbers');
const symbolsCheckbox = document.getElementById('symbols');

// Character sets
const UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
const NUMBERS = "0123456789";
const SYMBOLS = "!@#$%^&*()_+-={}[]<>?/";

// Generate password based on selected options
function generatePassword() {
    const length = parseInt(lengthInput.value);
    if (isNaN(length) || length < 4) {
        alert("Please enter a valid length (minimum 4)");
        return "";
    }

    let charset = "";
    if (uppercaseCheckbox.checked) charset += UPPERCASE;
    if (lowercaseCheckbox.checked) charset += LOWERCASE;
    if (numbersCheckbox.checked) charset += NUMBERS;
    if (symbolsCheckbox.checked) charset += SYMBOLS;

    if (charset === "") {
        alert("Select at least one character type!");
        return "";
    }

    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }

    return password;
}

// Copy to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text)
        .then(() => alert("Password copied to clipboard!"))
        .catch(() => alert("Failed to copy password"));
}

// Event Listeners
generateBtn.addEventListener('click', () => {
    const password = generatePassword();
    if(password) passwordDisplay.textContent = password;
});

copyBtn.addEventListener('click', () => {
    const password = passwordDisplay.textContent;
    if(password && password !== "Your password will appear here") {
        copyToClipboard(password);
    } else {
        alert("Generate a password first!");
    }
});
